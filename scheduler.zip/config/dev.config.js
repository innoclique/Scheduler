module.exports = {
  env: "dev",
  port: 8888,
  //database: "mongodb://constructionworld:constructionworld123@ds233769.mlab.com:33769/constructionworld",
  //database: "mongodb://testyovza:testyovza123@ds229373.mlab.com:29373/testyovza",
  //database: "mongodb://ithours:ithours123@35.233.211.32:27017/youzatesting",
  //database: "mongodb://35.240.157.192:27017/youzatesting",
   database: "mongodb://localhost:27017/HRPortal",
  
  smtp2: {
    smtp_user: "noreply@innoclique.com",
      host: 'smtp.zoho.com',
      port: 587,
      secureConnection: true, // use SSL
      auth: {
        user: 'noreply@innoclique.com',
        pass: '@#!ICQ!@#'
      },
      tls: {
        secureProtocol: "TLSv1_method"
      }
},
  
  APPOFSERVER: "http://18.220.238.10:9002/",
  APP_BASE_URL: "http://35.198.220.87/",
  secret: "inn@CliqueInnoCli@ue=$uperPoweR",
  TARGET_CONTACT_EMAIL : "madantfc@gmail.com",
  accessKeyId: 'AKIAJUBYLO6NUAUA7UHQ',
  secretAccessKey: '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',
  region: "us-west-2",
  bucket: 'dolphino',
ProductName:"OPAssess"
};