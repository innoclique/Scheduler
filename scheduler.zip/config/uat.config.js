module.exports = {
  env: "uat",
  port: 8002,
  database: "mongodb://ithours:ithours123@35.233.211.32:27017/youzatesting",
//  database: "mongodb://157.230.57.197:27017/youzatesting",
  //database : "mongodb://35.240.157.192:27017/youzatesting",
  smtp: {
    smtp_host: "smtp.gmail.com",
    smtp_user: "vishal.test123456@gmail.com",
    smtp_password: "vishal987654",  
    frommail: '"xxx - xx "<vishal.test123456@gmail.com>',
    title: "ManaB APP : ",
    smtp_port: 465,
    mailadmin: "vishal.test123456@gmail.com"
  },
  APPOFSERVER: "http://18.220.238.10:9002/",
  APP_BASE_URL: "http://uat.admin.yovza.com/",
  secret: "supersecret",
  TARGET_CONTACT_EMAIL : "madantfc@gmail.com",
  accessKeyId: 'AKIAJUBYLO6NUAUA7UHQ',
  secretAccessKey: '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',
  region: "us-west-2",
  bucket: 'dolphino'
};