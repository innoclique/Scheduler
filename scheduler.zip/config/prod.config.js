// module.exports = {
//   env: "prod",
//   port: 9002,
//   database: "mongodb://localhost:27017/yovzaprod2",
//   smtp: {
//     smtp_host: "smtp.zoho.com",
//     smtp_user: "noreply@yovza.com",
//     smtp_password: "Yovza@#99",
//     frommail: '"Yovza "<noreply@yovza.com>',
//     title: "Yovza",
//     smtp_port: 465,
//     mailadmin: "noreply@yovza.com"
//   },
//   APPOFSERVER: "http://18.220.238.10:9002/",
//   APP_BASE_URL: "https://admin.yovza.com/",
//   secret: "supersecret",
//   TARGET_CONTACT_EMAIL : "madantfc@gmail.com",
//   accessKeyId: 'AKIAJUBYLO6NUAUA7UHQ',
//   secretAccessKey: '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',
//   region: "us-west-2",
//   bucket: 'dolphino'
// };
module.exports = {
  env: "prod",
  port: 9100,
  //database: "mongodb://constructionworld:constructionworld123@ds233769.mlab.com:33769/constructionworld",
  //database: "mongodb://testyovza:testyovza123@ds229373.mlab.com:29373/testyovza",
  //database: "mongodb://ithours:ithours123@35.233.211.32:27017/youzatesting",
  //database: "mongodb://35.240.157.192:27017/youzatesting",
   database: "mongodb://localhost:27017/yovzaprod2",
  smtp: {
    smtp_host: "smtp.gmail.com",
    smtp_user: "vishal.test123456@gmail.com",
    smtp_password: "vishal987654",
    frommail: '"xxx - xx "<vishal.test123456@gmail.com>',
    title: "ManaB APP : ",
    mailadmin: "vishal.test123456@gmail.com"
  },
  smtp2: {
    smtp_user: "noreply@yovza.com",
    host: 'smtp.zoho.com',
    port: 587,
    secureConnection: true, // use SSL
    auth: {
        user: 'noreply@yovza.com',
        pass: 'Yovza*&^321'
    },
    tls: {
        secureProtocol: "TLSv1_method"
    }
},
  // smtp : {
  //     smtp_host: "smtp.gmail.com",
  //     smtp_user: "prakhar.gautam@ithours.com",
  //     smtp_password: "p952849965",
  //     frommail: '"ManaB - Admin "<prakhar.gautam@ithours.com>',
  //     title: "ManaB APP : ",
  //     mailadmin: 'prakhar.gautam@ithours.com'
  // },
  APPOFSERVER: "http://18.220.238.10:9002/",
  APP_BASE_URL: "https://portal.yovza.com/",
  secret: "supersecret",
  TARGET_CONTACT_EMAIL : "madantfc@gmail.com",
  accessKeyId: 'AKIAJUBYLO6NUAUA7UHQ',
  secretAccessKey: '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',
  region: "us-west-2",
  bucket: 'dolphino'
  //TARGET_CONTACT_EMAIL : "vishal.kumar1145@gmail.com"
  //TARGET_CONTACT_EMAIL : "pchand@ithours.com"

};